# NEXAT Market Dataset (AG3549)

This dataset contains structured information for the **NEXAT Market**, created from publicly available landing‑page data.

## Included Files
- summary.json
- segmentation.json
- companies.csv
- market_insights.json
- toc.txt
- README.md

## Disclaimer
No proprietary or paid report content is included. Only public data is used.
